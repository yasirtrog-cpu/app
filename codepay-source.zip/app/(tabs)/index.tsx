import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { ScrollView, Text, View, Pressable } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

const palette = {
  ink: "#081A2B",
  panel: "#102B40",
  panelSoft: "#15364C",
  mint: "#45E0B3",
  cream: "#F4F7F2",
  muted: "#9EB5C3",
  line: "#285067",
  gold: "#FFC857",
};

function StatusPill({ label, tone = "mint" }: { label: string; tone?: "mint" | "gold" }) {
  return (
    <View style={{ backgroundColor: tone === "mint" ? "#163F3A" : "#4A3B1A", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6, flexDirection: "row", alignItems: "center", gap: 6 }}>
      <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: tone === "mint" ? palette.mint : palette.gold }} />
      <Text style={{ color: tone === "mint" ? palette.mint : palette.gold, fontSize: 11, fontWeight: "700" }}>{label}</Text>
    </View>
  );
}

function QuickAction({ icon, label, detail, onPress }: { icon: keyof typeof MaterialIcons.glyphMap; label: string; detail: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [{ flex: 1, minHeight: 108, backgroundColor: palette.panelSoft, borderRadius: 18, padding: 16, justifyContent: "space-between", borderWidth: 1, borderColor: palette.line }, pressed && { opacity: 0.82, transform: [{ scale: 0.98 }] }]}>
      <View style={{ width: 34, height: 34, borderRadius: 12, backgroundColor: "#1B4E5A", alignItems: "center", justifyContent: "center" }}>
        <MaterialIcons name={icon} size={19} color={palette.mint} />
      </View>
      <View>
        <Text style={{ color: palette.cream, fontSize: 14, fontWeight: "800", textAlign: "right" }}>{label}</Text>
        <Text style={{ color: palette.muted, fontSize: 11, marginTop: 3, textAlign: "right" }}>{detail}</Text>
      </View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const catalog = trpc.catalog.get.useQuery();
  const providerReady = catalog.data?.paymentProviderConfigured ?? false;

  return (
    <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]" edges={["top", "left", "right"]}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 36 }} showsVerticalScrollIndicator={false}>
        <View style={{ direction: "rtl", gap: 18 }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <View style={{ width: 42, height: 42, borderRadius: 15, backgroundColor: palette.mint, alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name="qr-code-2" size={25} color={palette.ink} />
              </View>
              <View>
                <Text style={{ color: palette.cream, fontSize: 20, fontWeight: "900", letterSpacing: -0.4 }}>CodePay</Text>
                <Text style={{ color: palette.muted, fontSize: 11, marginTop: 2 }}>أكواد اشتراك بحالة واضحة</Text>
              </View>
            </View>
            <StatusPill label="النظام يعمل" />
          </View>

          <View style={{ backgroundColor: palette.panel, borderRadius: 25, padding: 20, borderWidth: 1, borderColor: palette.line, overflow: "hidden" }}>
            <View style={{ position: "absolute", width: 160, height: 160, borderRadius: 80, backgroundColor: "#123B4A", top: -70, left: -30, opacity: 0.7 }} />
            <View style={{ position: "relative", gap: 14 }}>
              <Text style={{ color: palette.mint, fontSize: 12, fontWeight: "800", letterSpacing: 1 }}>لوحة الأكواد / 01</Text>
              <Text style={{ color: palette.cream, fontSize: 29, lineHeight: 36, fontWeight: "900", textAlign: "right" }}>اختر المدة،{"\n"}والباقي علينا.</Text>
              <Text style={{ color: palette.muted, fontSize: 14, lineHeight: 22, textAlign: "right" }}>أكواد ثابتة من 7 أحرف، تنتهي تلقائيًا حسب مدة الاشتراك وتصل بعد تأكيد الدفع.</Text>
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 5 }}>
                <StatusPill label={providerReady ? "الدفع متصل" : "وضع المعاينة"} tone={providerReady ? "mint" : "gold"} />
                <Text style={{ color: palette.muted, fontSize: 11 }}>تسعير يبدأ من 1$ / كود</Text>
              </View>
            </View>
          </View>

          <View style={{ flexDirection: "row", gap: 10 }}>
            <QuickAction icon="add-shopping-cart" label="شراء أكواد" detail="مدد من يوم إلى شهر" onPress={() => router.push("/(tabs)/store")} />
            <QuickAction icon="verified-user" label="تحقق سريع" detail="افحص حالة أي كود" onPress={() => router.push("/(tabs)/verify")} />
          </View>

          <View style={{ gap: 10 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={{ color: palette.cream, fontSize: 17, fontWeight: "800" }}>نظرة تشغيلية</Text>
              <Text style={{ color: palette.muted, fontSize: 11 }}>تحديث الآن</Text>
            </View>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <View style={{ flex: 1, backgroundColor: palette.panel, padding: 15, borderRadius: 18, borderWidth: 1, borderColor: palette.line }}>
                <Text style={{ color: palette.muted, fontSize: 11, textAlign: "right" }}>طول الكود</Text>
                <Text style={{ color: palette.cream, fontSize: 24, fontWeight: "900", marginTop: 8, textAlign: "right" }}>07</Text>
                <Text style={{ color: palette.mint, fontSize: 11, marginTop: 2, textAlign: "right" }}>ثابت وآمن</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: palette.panel, padding: 15, borderRadius: 18, borderWidth: 1, borderColor: palette.line }}>
                <Text style={{ color: palette.muted, fontSize: 11, textAlign: "right" }}>فحص API</Text>
                <Text style={{ color: palette.cream, fontSize: 24, fontWeight: "900", marginTop: 8, textAlign: "right" }}>200</Text>
                <Text style={{ color: palette.mint, fontSize: 11, marginTop: 2, textAlign: "right" }}>متاح للتطبيق الآخر</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: palette.panel, padding: 15, borderRadius: 18, borderWidth: 1, borderColor: palette.line }}>
                <Text style={{ color: palette.muted, fontSize: 11, textAlign: "right" }}>التسليم</Text>
                <Text style={{ color: palette.cream, fontSize: 24, fontWeight: "900", marginTop: 8, textAlign: "right" }}>&lt;10s</Text>
                <Text style={{ color: palette.gold, fontSize: 11, marginTop: 2, textAlign: "right" }}>بعد التأكيد</Text>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: "#0C2436", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: palette.line, flexDirection: "row", alignItems: "center", gap: 12 }}>
            <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: "#173C50", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="api" size={20} color={palette.mint} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: palette.cream, fontWeight: "800", textAlign: "right" }}>نقطة التحقق جاهزة</Text>
              <Text style={{ color: palette.muted, fontSize: 11, marginTop: 4, textAlign: "right" }}>GET /api/codes/verify?code=XXXXXXX</Text>
            </View>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: palette.mint }} />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
