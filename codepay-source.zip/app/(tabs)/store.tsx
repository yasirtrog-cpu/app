import { MaterialIcons } from "@expo/vector-icons";
import { ScrollView, Text, View, Pressable, ActivityIndicator, Platform } from "react-native";
import { useMemo, useState } from "react";
import React from "react";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

const colors = { ink: "#081A2B", panel: "#102B40", panelSoft: "#15364C", mint: "#45E0B3", cream: "#F4F7F2", muted: "#9EB5C3", line: "#285067", gold: "#FFC857", red: "#FF7D8A" };
const fallbackDurations = [
  { days: 1, label: "يوم واحد", pricePerCode: 1, hint: "تجربة سريعة" },
  { days: 2, label: "يومان", pricePerCode: 2, hint: "48 ساعة" },
  { days: 3, label: "3 أيام", pricePerCode: 3, hint: "عمليات قصيرة" },
  { days: 7, label: "أسبوع", pricePerCode: 7, hint: "الأكثر مرونة" },
  { days: 30, label: "شهر", pricePerCode: 30, hint: "اشتراك كامل" },
] as const;
const fallbackMethods = [
  { id: "usdt_trc20", label: "USDT", network: "TRC20", symbol: "₮" },
  { id: "trx", label: "TRX", network: "TRON", symbol: "T" },
  { id: "ton", label: "TON", network: "TON Network", symbol: "◈" },
  { id: "usdt_bep20", label: "USDT", network: "BEP20", symbol: "₮" },
] as const;

type OrderResult = { orderId: string; amountUsd: number; quantity: number; subscriptionDays: number; paymentAddress: string | null; providerReference: string | null; mode: "demo" | "external"; note: string; paymentMethod: { label: string; network: string; symbol: string } };

type GeneratedCode = { code: string; expiresAt: Date | string; subscriptionDays: number };

function StepLabel({ number, label }: { number: string; label: string }) {
  return <View style={{ flexDirection: "row", alignItems: "center", gap: 9 }}><View style={{ width: 25, height: 25, borderRadius: 9, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.ink, fontWeight: "900", fontSize: 12 }}>{number}</Text></View><Text style={{ color: colors.cream, fontSize: 16, fontWeight: "800" }}>{label}</Text></View>;
}

export default function StoreScreen() {
  const catalog = trpc.catalog.get.useQuery();
  const [duration, setDuration] = useState(1);
  const [quantity, setQuantity] = useState(1);
  const [method, setMethod] = useState("usdt_trc20");
  const [order, setOrder] = useState<OrderResult | null>(null);
  const [codes, setCodes] = useState<GeneratedCode[]>([]);
  const [proofMessage, setProofMessage] = useState("");
  const [error, setError] = useState("");
  const durations = catalog.data?.durations ?? fallbackDurations;
  const methods = catalog.data?.paymentMethods ?? fallbackMethods;
  const selectedDuration = durations.find((item) => item.days === duration) ?? durations[0];
  const total = useMemo(() => quantity * selectedDuration.pricePerCode, [quantity, selectedDuration]);
  const createOrder = trpc.orders.create.useMutation({
    onSuccess: (data) => { setOrder(data); setCodes([]); setError(""); },
    onError: (err) => setError(err.message),
  });
  const submitProof = trpc.orders.submitProof.useMutation({
    onSuccess: () => setProofMessage("تم رفع الصورة. سيظهر الطلب للمدير للمراجعة."),
    onError: (err) => setProofMessage(err.message),
  });

  const handleProofFile = (event: any) => {
    const file = event?.target?.files?.[0];
    if (!file || !order) return;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      setProofMessage("اختر صورة JPG أو PNG أو WebP فقط.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setProofMessage("حجم الصورة يجب ألا يتجاوز 5MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const data = typeof reader.result === "string" ? reader.result : "";
      submitProof.mutate({ orderId: order.orderId, fileName: file.name, mimeType: file.type, base64: data });
    };
    reader.readAsDataURL(file);
  };

  const submitOrder = () => {
    setError("");
    createOrder.mutate({ quantity, subscriptionDays: duration as 1 | 2 | 3 | 7 | 30, paymentMethod: method as "usdt_trc20" | "trx" | "ton" | "usdt_bep20" });
  };

  return (
    <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]" edges={["top", "left", "right"]}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 42 }} showsVerticalScrollIndicator={false}>
        <View style={{ direction: "rtl", gap: 18 }}>
          <View style={{ gap: 6 }}>
            <Text style={{ color: colors.mint, fontSize: 12, fontWeight: "900", letterSpacing: 1 }}>STORE / 02</Text>
            <Text style={{ color: colors.cream, fontSize: 29, lineHeight: 36, fontWeight: "900" }}>جهّز دفعتك.</Text>
            <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 22 }}>حدد المدة والعدد، وسيظل طول الكود ثابتًا عند 7 أحرف.</Text>
          </View>

          <View style={{ backgroundColor: colors.panel, borderRadius: 22, padding: 17, borderWidth: 1, borderColor: colors.line, gap: 15 }}>
            <StepLabel number="01" label="مدة الاشتراك" />
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 9 }}>
              {durations.map((item) => {
                const selected = item.days === duration;
                return <Pressable key={item.days} onPress={() => { setDuration(item.days); setOrder(null); setCodes([]); }} style={({ pressed }) => [{ width: "31%", minWidth: 94, flexGrow: 1, padding: 12, borderRadius: 15, backgroundColor: selected ? "#1B4E5A" : colors.panelSoft, borderWidth: 1, borderColor: selected ? colors.mint : colors.line }, pressed && { opacity: 0.8 }]}>
                  <Text style={{ color: selected ? colors.mint : colors.cream, fontWeight: "900", textAlign: "right", fontSize: 13 }}>{item.label}</Text>
                  <Text style={{ color: colors.muted, fontSize: 10, textAlign: "right", marginTop: 4 }}>{item.hint}</Text>
                  <Text style={{ color: colors.cream, fontSize: 14, fontWeight: "900", textAlign: "right", marginTop: 9 }}>${item.pricePerCode}<Text style={{ color: colors.muted, fontSize: 10, fontWeight: "500" }}> / كود</Text></Text>
                </Pressable>;
              })}
            </View>
          </View>

          <View style={{ backgroundColor: colors.panel, borderRadius: 22, padding: 17, borderWidth: 1, borderColor: colors.line, gap: 15 }}>
            <StepLabel number="02" label="عدد الأكواد" />
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.panelSoft, borderRadius: 16, padding: 8, paddingLeft: 16 }}>
              <View><Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>الإجمالي</Text><Text style={{ color: colors.mint, fontSize: 23, fontWeight: "900", textAlign: "right", marginTop: 2 }}>${total.toFixed(2)}</Text></View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
                <Pressable onPress={() => setQuantity((value) => Math.max(1, value - 1))} style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: "#1B4E5A", alignItems: "center", justifyContent: "center" }}><MaterialIcons name="remove" size={19} color={colors.cream} /></Pressable>
                <Text style={{ color: colors.cream, fontSize: 25, fontWeight: "900", minWidth: 30, textAlign: "center" }}>{quantity}</Text>
                <Pressable onPress={() => setQuantity((value) => Math.min(100, value + 1))} style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" }}><MaterialIcons name="add" size={19} color={colors.ink} /></Pressable>
              </View>
            </View>
            <Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>السعر محسوب على أساس ${selectedDuration.pricePerCode} لكل كود لمدة {selectedDuration.days} {selectedDuration.days === 1 ? "يوم" : "أيام"}.</Text>
          </View>

          <View style={{ backgroundColor: colors.panel, borderRadius: 22, padding: 17, borderWidth: 1, borderColor: colors.line, gap: 15 }}>
            <StepLabel number="03" label="طريقة الدفع" />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 9, flexDirection: "row-reverse" }}>
              {methods.map((item) => {
                const selected = item.id === method;
                return <Pressable key={item.id} onPress={() => { setMethod(item.id); setOrder(null); setCodes([]); }} style={({ pressed }) => [{ minWidth: 108, padding: 12, borderRadius: 15, backgroundColor: selected ? "#1B4E5A" : colors.panelSoft, borderWidth: 1, borderColor: selected ? colors.mint : colors.line }, pressed && { opacity: 0.8 }]}>
                  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><Text style={{ color: selected ? colors.mint : colors.cream, fontSize: 17, fontWeight: "900" }}>{item.symbol}</Text><View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: selected ? colors.mint : colors.line }} /></View>
                  <Text style={{ color: colors.cream, fontSize: 13, fontWeight: "800", marginTop: 9, textAlign: "right" }}>{item.label}</Text>
                  <Text style={{ color: colors.muted, fontSize: 10, marginTop: 3, textAlign: "right" }}>{item.network}</Text>
                </Pressable>;
              })}
            </ScrollView>
          </View>

          {error ? <View style={{ backgroundColor: "#3D2029", borderRadius: 14, padding: 13, borderWidth: 1, borderColor: "#6E3544" }}><Text style={{ color: colors.red, fontSize: 12, lineHeight: 19, textAlign: "right" }}>{error}</Text></View> : null}

          {!order ? <Pressable onPress={submitOrder} disabled={createOrder.isPending} style={({ pressed }) => [{ backgroundColor: colors.mint, borderRadius: 17, minHeight: 56, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9 }, pressed && { opacity: 0.85 }, createOrder.isPending && { opacity: 0.65 }]}>
            {createOrder.isPending ? <ActivityIndicator color={colors.ink} /> : <><MaterialIcons name="arrow-back" size={20} color={colors.ink} /><Text style={{ color: colors.ink, fontSize: 16, fontWeight: "900" }}>إنشاء طلب الدفع · ${total.toFixed(2)}</Text></>}
          </Pressable> : (
            <View style={{ backgroundColor: colors.panel, borderRadius: 22, padding: 17, borderWidth: 1, borderColor: order.mode === "demo" ? "#80652A" : colors.mint, gap: 14 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.cream, fontSize: 17, fontWeight: "900" }}>طلب {order.orderId}</Text><View style={{ backgroundColor: order.mode === "demo" ? "#4A3B1A" : "#163F3A", borderRadius: 999, paddingHorizontal: 9, paddingVertical: 5 }}><Text style={{ color: order.mode === "demo" ? colors.gold : colors.mint, fontSize: 10, fontWeight: "800" }}>{order.mode === "demo" ? "معاينة" : "دفع متصل"}</Text></View></View>
              <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 19, textAlign: "right" }}>{order.note}. أرسل ${order.amountUsd.toFixed(2)} عبر {order.paymentMethod.label} / {order.paymentMethod.network} ثم انتظر التأكيد.</Text>
              <View style={{ backgroundColor: colors.panelSoft, borderRadius: 14, padding: 13, gap: 7 }}><Text style={{ color: colors.muted, fontSize: 10, textAlign: "right" }}>عنوان الدفع</Text><Text selectable style={{ color: order.paymentAddress ? colors.cream : colors.gold, fontFamily: "monospace", fontSize: 12, textAlign: "right" }}>{order.paymentAddress ?? "لم يُضبط عنوان المحفظة بعد"}</Text></View>
              {Platform.OS === "web" ? <View style={{ gap: 8 }}><Text style={{ color: colors.cream, fontSize: 13, fontWeight: "800", textAlign: "right" }}>أرفق صورة إثبات الدفع</Text>{React.createElement("input", { type: "file", accept: "image/jpeg,image/png,image/webp", onChange: handleProofFile, style: { color: colors.cream, width: "100%" } })}<Text style={{ color: colors.muted, fontSize: 10, textAlign: "right" }}>JPG أو PNG أو WebP — الحد الأقصى 5MB.</Text>{proofMessage ? <Text style={{ color: proofMessage.startsWith("تم") ? colors.mint : colors.gold, fontSize: 11, textAlign: "right" }}>{proofMessage}</Text> : null}</View> : <Text style={{ color: colors.gold, fontSize: 12, textAlign: "right" }}>رفع الصورة متاح في نسخة الويب حاليًا.</Text>}
              <Text style={{ color: colors.gold, fontSize: 12, lineHeight: 19, textAlign: "right" }}>حالة الطلب: بانتظار مراجعة المدير. لن يتم تسليم الأكواد إلا بعد قبول صورة الدفع من لوحة الإدارة.</Text>
            </View>
          )}

          {codes.length > 0 ? <View style={{ backgroundColor: "#102F37", borderRadius: 22, padding: 17, borderWidth: 1, borderColor: colors.mint, gap: 13 }}><View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.mint, fontSize: 17, fontWeight: "900" }}>أكوادك جاهزة</Text><Text style={{ color: colors.muted, fontSize: 11 }}>{codes.length} كود</Text></View><Text style={{ color: colors.muted, fontSize: 12, lineHeight: 19, textAlign: "right" }}>هذه أكواد تجريبية في وضع المعاينة. في الإنتاج لا تُسلّم إلا بعد webhook الدفع الحقيقي.</Text>{codes.map((item) => <View key={item.code} style={{ backgroundColor: colors.ink, borderRadius: 14, padding: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text selectable style={{ color: colors.cream, fontFamily: "monospace", letterSpacing: 2, fontSize: 18, fontWeight: "800" }}>{item.code}</Text><View style={{ backgroundColor: "#163F3A", borderRadius: 999, paddingHorizontal: 8, paddingVertical: 5 }}><Text style={{ color: colors.mint, fontSize: 10, fontWeight: "800" }}>ACTIVE</Text></View></View>)}</View> : null}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
