import { MaterialIcons } from "@expo/vector-icons";
import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";

const colors = { ink: "#081A2B", panel: "#102B40", panelSoft: "#15364C", mint: "#45E0B3", cream: "#F4F7F2", muted: "#9EB5C3", line: "#285067", gold: "#FFC857", red: "#FF7D8A" };

export default function VerifyScreen() {
  const [value, setValue] = useState("");
  const verify = trpc.codes.verify.useMutation();
  const result = verify.data;
  const submit = () => { if (value.trim()) verify.mutate({ code: value.trim() }); };

  return (
    <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]" edges={["top", "left", "right"]}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 42 }} showsVerticalScrollIndicator={false}>
        <View style={{ direction: "rtl", gap: 18 }}>
          <View style={{ gap: 6 }}>
            <Text style={{ color: colors.mint, fontSize: 12, fontWeight: "900", letterSpacing: 1 }}>VERIFY / 03</Text>
            <Text style={{ color: colors.cream, fontSize: 29, lineHeight: 36, fontWeight: "900" }}>تأكد قبل أن تبدأ.</Text>
            <Text style={{ color: colors.muted, fontSize: 14, lineHeight: 22 }}>أدخل الكود كما هو. النتيجة نفسها متاحة للتطبيق الآخر عبر API.</Text>
          </View>

          <View style={{ backgroundColor: colors.panel, borderRadius: 22, padding: 18, borderWidth: 1, borderColor: colors.line, gap: 14 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}><View style={{ width: 34, height: 34, borderRadius: 12, backgroundColor: "#1B4E5A", alignItems: "center", justifyContent: "center" }}><MaterialIcons name="verified-user" size={19} color={colors.mint} /></View><Text style={{ color: colors.cream, fontSize: 17, fontWeight: "900" }}>تحقق من كود</Text></View>
            <TextInput value={value} onChangeText={(text) => setValue(text.toUpperCase().replace(/[^A-Z0-9]/g, ""))} placeholder="مثال: A7K9Q2M" placeholderTextColor="#668392" maxLength={7} autoCapitalize="characters" autoCorrect={false} style={{ backgroundColor: colors.panelSoft, borderWidth: 1, borderColor: colors.line, borderRadius: 15, minHeight: 58, paddingHorizontal: 15, color: colors.cream, fontFamily: "monospace", fontSize: 21, letterSpacing: 3, textAlign: "center" }} />
            <Pressable onPress={submit} disabled={!value.trim() || verify.isPending} style={({ pressed }) => [{ backgroundColor: colors.mint, borderRadius: 15, minHeight: 52, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8 }, pressed && { opacity: 0.85 }, (!value.trim() || verify.isPending) && { opacity: 0.55 }]}>{verify.isPending ? <ActivityIndicator color={colors.ink} /> : <><MaterialIcons name="search" size={20} color={colors.ink} /><Text style={{ color: colors.ink, fontWeight: "900", fontSize: 15 }}>تحقق الآن</Text></>}</Pressable>
          </View>

          {result ? <View style={{ backgroundColor: result.valid ? "#102F37" : "#3D2029", borderRadius: 22, padding: 18, borderWidth: 1, borderColor: result.valid ? colors.mint : "#6E3544", gap: 13 }}><View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><Text style={{ color: result.valid ? colors.mint : colors.red, fontSize: 20, fontWeight: "900" }}>{result.valid ? "الكود يعمل" : result.exists ? "الكود منتهي" : "الكود غير موجود"}</Text><MaterialIcons name={result.valid ? "check-circle" : "error"} size={27} color={result.valid ? colors.mint : colors.red} /></View><Text style={{ color: colors.muted, fontSize: 12, lineHeight: 20, textAlign: "right" }}>{result.valid ? `صالح لمدة ${result.subscriptionDays ?? "—"} يوم.` : "تحقق من الكتابة أو اطلب كودًا جديدًا من المتجر."}</Text><View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: colors.ink, borderRadius: 13, padding: 12 }}><Text style={{ color: colors.muted, fontSize: 11 }}>المصدر</Text><Text style={{ color: colors.cream, fontSize: 11, fontWeight: "800" }}>{result.source === "external" ? "API خارجي" : "قاعدة CodePay"}</Text></View>{result.expiresAt ? <View style={{ flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 2 }}><Text style={{ color: colors.muted, fontSize: 11 }}>ينتهي في</Text><Text style={{ color: colors.cream, fontSize: 11 }}>{new Date(result.expiresAt).toLocaleDateString("ar-EG")}</Text></View> : null}</View> : null}

          {verify.error ? <View style={{ backgroundColor: "#3D2029", borderRadius: 14, padding: 13, borderWidth: 1, borderColor: "#6E3544" }}><Text style={{ color: colors.red, fontSize: 12, textAlign: "right" }}>{verify.error.message}</Text></View> : null}

          <View style={{ backgroundColor: colors.panel, borderRadius: 19, padding: 16, borderWidth: 1, borderColor: colors.line, gap: 10 }}><View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.cream, fontSize: 15, fontWeight: "900" }}>للتطبيق الآخر</Text><View style={{ backgroundColor: "#163F3A", borderRadius: 999, paddingHorizontal: 8, paddingVertical: 5 }}><Text style={{ color: colors.mint, fontSize: 10, fontWeight: "800" }}>API READY</Text></View></View><Text selectable style={{ color: colors.mint, fontFamily: "monospace", fontSize: 11, lineHeight: 19, textAlign: "left" }}>GET /api/codes/verify?code=XXXXXXX</Text><Text style={{ color: colors.muted, fontSize: 11, lineHeight: 18, textAlign: "right" }}>يمكن حماية الطلب بمفتاح `x-api-key` من إعدادات الخادم عند تفعيل الإنتاج.</Text></View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
