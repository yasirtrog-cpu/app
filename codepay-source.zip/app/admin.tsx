import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { ActivityIndicator, Image, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import { startOAuthLogin } from "@/constants/oauth";

const colors = { ink: "#081A2B", panel: "#102B40", panelSoft: "#15364C", mint: "#45E0B3", cream: "#F4F7F2", muted: "#9EB5C3", line: "#285067", gold: "#FFC857", red: "#FF7D8A" };
const walletMethods = [
  { id: "usdt_trc20", label: "USDT", network: "TRC20" },
  { id: "trx", label: "TRX", network: "TRON" },
  { id: "ton", label: "TON", network: "TON Network" },
  { id: "usdt_bep20", label: "USDT", network: "BEP20" },
] as const;

function statusLabel(status: string) {
  if (status === "pending") return "بانتظار المراجعة";
  if (status === "fulfilled") return "تم التسليم";
  if (status === "failed") return "مرفوض";
  if (status === "paid") return "مدفوع";
  return status;
}

export default function AdminScreen() {
  const router = useRouter();
  const auth = trpc.auth.me.useQuery();
  const overview = trpc.admin.overview.useQuery(undefined, { enabled: auth.data?.role === "admin" });
  const review = trpc.admin.reviewOrder.useMutation({ onSuccess: () => overview.refetch() });
  const saveWallet = trpc.admin.saveWallet.useMutation({ onSuccess: () => overview.refetch() });
  const [reason, setReason] = useState("");
  const [wallets, setWallets] = useState<Record<string, string>>({});

  const settingsById = useMemo(() => new Map((overview.data?.settings ?? []).map((item) => [item.methodId, item])), [overview.data?.settings]);
  const pendingOrders = (overview.data?.orders ?? []).filter((order) => order.status === "pending" || order.status === "paid");

  if (auth.isLoading) {
    return <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]"><View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}><ActivityIndicator color={colors.mint} /></View></ScreenContainer>;
  }

  if (!auth.data) {
    return <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]"><View style={{ flex: 1, padding: 24, alignItems: "center", justifyContent: "center", gap: 14, direction: "rtl" }}><MaterialIcons name="lock" size={42} color={colors.mint} /><Text style={{ color: colors.cream, fontSize: 24, fontWeight: "900", textAlign: "center" }}>لوحة الإدارة محمية</Text><Text style={{ color: colors.muted, fontSize: 14, lineHeight: 22, textAlign: "center" }}>سجّل الدخول بحساب Manus المصرّح له بالإدارة. لن تظهر الطلبات أو عناوين المحافظ قبل التحقق من الصلاحية.</Text><Pressable onPress={() => startOAuthLogin()} style={{ backgroundColor: colors.mint, borderRadius: 15, paddingHorizontal: 24, minHeight: 50, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.ink, fontWeight: "900" }}>تسجيل الدخول</Text></Pressable><Pressable onPress={() => router.replace("/")}><Text style={{ color: colors.muted, fontSize: 12 }}>العودة للتطبيق</Text></Pressable></View></ScreenContainer>;
  }

  if (auth.data.role !== "admin") {
    return <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]"><View style={{ flex: 1, padding: 24, alignItems: "center", justifyContent: "center", gap: 14, direction: "rtl" }}><MaterialIcons name="gpp-bad" size={44} color={colors.red} /><Text style={{ color: colors.cream, fontSize: 24, fontWeight: "900", textAlign: "center" }}>لا تملك صلاحية الإدارة</Text><Text style={{ color: colors.muted, fontSize: 14, lineHeight: 22, textAlign: "center" }}>حسابك مسجل، لكنه ليس ضمن دور admin. أضف معرف الحساب إلى إعدادات المالك ثم أعد تسجيل الدخول.</Text><Pressable onPress={() => router.replace("/")}><Text style={{ color: colors.mint, fontWeight: "800" }}>العودة للتطبيق</Text></Pressable></View></ScreenContainer>;
  }

  return <ScreenContainer containerClassName="bg-[#081A2B]" safeAreaClassName="bg-[#081A2B]" edges={["top", "left", "right"]}>
    <ScrollView contentContainerStyle={{ padding: 22, paddingBottom: 48 }} showsVerticalScrollIndicator={false}>
      <View style={{ direction: "rtl", gap: 18 }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><View><Text style={{ color: colors.mint, fontSize: 12, fontWeight: "900", letterSpacing: 1 }}>ADMIN / CONTROL ROOM</Text><Text style={{ color: colors.cream, fontSize: 29, fontWeight: "900", marginTop: 6 }}>لوحة الإدارة</Text><Text style={{ color: colors.muted, fontSize: 13, marginTop: 5 }}>مراجعة الدفع قبل تسليم الأكواد.</Text></View><View style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" }}><MaterialIcons name="admin-panel-settings" size={25} color={colors.ink} /></View></View>

        <View style={{ flexDirection: "row", gap: 10 }}><View style={{ flex: 1, backgroundColor: colors.panel, borderRadius: 17, padding: 14, borderWidth: 1, borderColor: colors.line }}><Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>طلبات تحتاج قرار</Text><Text style={{ color: colors.gold, fontSize: 27, fontWeight: "900", marginTop: 5, textAlign: "right" }}>{pendingOrders.length}</Text></View><View style={{ flex: 1, backgroundColor: colors.panel, borderRadius: 17, padding: 14, borderWidth: 1, borderColor: colors.line }}><Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>إجمالي الطلبات</Text><Text style={{ color: colors.mint, fontSize: 27, fontWeight: "900", marginTop: 5, textAlign: "right" }}>{overview.data?.orders.length ?? 0}</Text></View></View>

        <View style={{ backgroundColor: colors.panel, borderRadius: 21, padding: 17, borderWidth: 1, borderColor: colors.line, gap: 13 }}><Text style={{ color: colors.cream, fontSize: 18, fontWeight: "900" }}>عناوين المحافظ</Text><Text style={{ color: colors.muted, fontSize: 12, lineHeight: 19 }}>غيّر العنوان من هنا. الطلبات الجديدة فقط ستستخدم العنوان الجديد؛ الطلبات القديمة تحتفظ بعنوانها وقت الإنشاء.</Text>{walletMethods.map((method) => { const saved = settingsById.get(method.id); const value = wallets[method.id] ?? saved?.address ?? ""; return <View key={method.id} style={{ gap: 7 }}><Text style={{ color: colors.cream, fontSize: 12, fontWeight: "800", textAlign: "right" }}>{method.label} · {method.network}</Text><View style={{ flexDirection: "row", gap: 8 }}><TextInput value={value} onChangeText={(text) => setWallets((current) => ({ ...current, [method.id]: text }))} placeholder="عنوان المحفظة" placeholderTextColor="#668392" autoCapitalize="none" style={{ flex: 1, minHeight: 46, backgroundColor: colors.panelSoft, borderWidth: 1, borderColor: colors.line, borderRadius: 12, color: colors.cream, fontSize: 12, paddingHorizontal: 11, textAlign: "left" }} /><Pressable onPress={() => saveWallet.mutate({ methodId: method.id, address: value, enabled: true })} style={{ width: 70, minHeight: 46, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.ink, fontSize: 11, fontWeight: "900" }}>حفظ</Text></Pressable></View></View>; })}</View>

        <View style={{ gap: 12 }}><Text style={{ color: colors.cream, fontSize: 18, fontWeight: "900" }}>طلبات الدفع</Text>{overview.isLoading ? <ActivityIndicator color={colors.mint} /> : pendingOrders.length === 0 ? <View style={{ backgroundColor: colors.panel, borderRadius: 17, padding: 18, borderWidth: 1, borderColor: colors.line }}><Text style={{ color: colors.muted, textAlign: "right" }}>لا توجد طلبات معلقة للمراجعة.</Text></View> : pendingOrders.map((order) => <View key={order.publicId} style={{ backgroundColor: colors.panel, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: colors.gold, gap: 12 }}><View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}><Text style={{ color: colors.gold, fontWeight: "900", fontSize: 14 }}>{statusLabel(order.status)}</Text><Text style={{ color: colors.cream, fontWeight: "900", fontSize: 16 }}>{order.publicId}</Text></View><View style={{ flexDirection: "row", justifyContent: "space-between" }}><Text style={{ color: colors.muted, fontSize: 12 }}>{order.quantity} كود · {order.subscriptionDays} يوم</Text><Text style={{ color: colors.mint, fontWeight: "900" }}>${(order.totalCents / 100).toFixed(2)}</Text></View><Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>طريقة الدفع: {order.paymentMethod} · العنوان المستخدم: {order.paymentAddress || "غير مضبوط"}</Text>{order.proofUrl ? <Image source={{ uri: order.proofUrl }} style={{ width: "100%", height: 230, borderRadius: 14, backgroundColor: colors.panelSoft }} resizeMode="contain" /> : <View style={{ padding: 14, borderRadius: 13, backgroundColor: "#3D2029" }}><Text style={{ color: colors.red, fontSize: 12, textAlign: "right" }}>لم يرفق العميل صورة إثبات الدفع.</Text></View>}<TextInput value={reason} onChangeText={setReason} placeholder="سبب الرفض (اختياري)" placeholderTextColor="#668392" style={{ minHeight: 44, backgroundColor: colors.panelSoft, borderWidth: 1, borderColor: colors.line, borderRadius: 12, color: colors.cream, paddingHorizontal: 11, textAlign: "right" }} /><View style={{ flexDirection: "row", gap: 9 }}><Pressable onPress={() => review.mutate({ orderId: order.publicId, decision: "reject", rejectReason: reason })} style={{ flex: 1, minHeight: 48, borderRadius: 13, backgroundColor: "#642E3A", alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.red, fontWeight: "900" }}>رفض الطلب</Text></Pressable><Pressable disabled={!order.proofUrl || review.isPending} onPress={() => review.mutate({ orderId: order.publicId, decision: "approve" })} style={{ flex: 1, minHeight: 48, borderRadius: 13, backgroundColor: order.proofUrl ? colors.mint : "#3D515A", alignItems: "center", justifyContent: "center" }}><Text style={{ color: order.proofUrl ? colors.ink : colors.muted, fontWeight: "900" }}>قبول وتسليم الأكواد</Text></Pressable></View></View>)}</View>

        <View style={{ backgroundColor: "#0C2436", borderRadius: 16, padding: 14, borderWidth: 1, borderColor: colors.line }}><Text style={{ color: colors.muted, fontSize: 11, lineHeight: 18, textAlign: "right" }}>مسار الإدارة في نسخة الويب: <Text style={{ color: colors.mint, fontFamily: Platform.OS === "web" ? "monospace" : undefined }}> /admin</Text>. الوصول محمي بدور admin على الخادم وليس بإخفاء الرابط فقط.</Text></View>
      </View>
    </ScrollView>
  </ScreenContainer>;
}
