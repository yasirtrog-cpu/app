import crypto from "node:crypto";

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export const FIXED_CODE_LENGTH = 7;

function config() {
  return {
    baseUrl: process.env.CODE_API_BASE_URL?.replace(/\/$/, "") ?? "",
    createPath: process.env.CODE_API_CREATE_PATH ?? "/codes",
    verifyPath: process.env.CODE_API_VERIFY_PATH ?? "/codes/verify",
    apiKey: process.env.CODE_API_KEY ?? "",
  };
}

function headers(apiKey: string) {
  return {
    accept: "application/json",
    "content-type": "application/json",
    ...(apiKey ? { authorization: `Bearer ${apiKey}` } : {}),
  };
}

export function generateCode() {
  let value = "";
  for (let index = 0; index < FIXED_CODE_LENGTH; index += 1) {
    value += CODE_ALPHABET[crypto.randomInt(0, CODE_ALPHABET.length)];
  }
  return value;
}

export async function pushCodesToExternalApi(input: {
  codes: string[];
  subscriptionDays: number;
  expiresAt: Date;
}) {
  const { baseUrl, createPath, apiKey } = config();
  if (!baseUrl) return { mode: "local" as const };
  const response = await fetch(`${baseUrl}${createPath}`, {
    method: "POST",
    headers: headers(apiKey),
    body: JSON.stringify({
      codes: input.codes,
      subscriptionDays: input.subscriptionDays,
      expiresAt: input.expiresAt.toISOString(),
    }),
  });
  const body = await response.text();
  if (!response.ok) {
    throw new Error(`External code API rejected the request (${response.status}): ${body.slice(0, 240)}`);
  }
  return { mode: "external" as const, response: body ? JSON.parse(body) : null };
}

export async function verifyCodeWithExternalApi(code: string) {
  const { baseUrl, verifyPath, apiKey } = config();
  if (!baseUrl) return null;
  const url = new URL(`${baseUrl}${verifyPath}`);
  url.searchParams.set("code", code);
  const response = await fetch(url, { headers: headers(apiKey) });
  const body = await response.text();
  if (!response.ok) {
    throw new Error(`External code API verification failed (${response.status}): ${body.slice(0, 240)}`);
  }
  const parsed = body ? (JSON.parse(body) as Record<string, unknown>) : {};
  return {
    exists: Boolean(parsed.exists ?? parsed.found ?? parsed.valid),
    valid: Boolean(parsed.valid ?? parsed.active),
    status: typeof parsed.status === "string" ? parsed.status : Boolean(parsed.valid) ? "active" : "unknown",
    expiresAt: typeof parsed.expiresAt === "string" ? parsed.expiresAt : null,
    subscriptionDays: typeof parsed.subscriptionDays === "number" ? parsed.subscriptionDays : null,
    source: "external" as const,
  };
}

export function isExternalCodeApiConfigured() {
  return Boolean(config().baseUrl);
}
