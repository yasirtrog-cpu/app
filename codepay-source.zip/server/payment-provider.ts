export const PAYMENT_METHODS = [
  { id: "usdt_trc20", label: "USDT", network: "TRC20", symbol: "₮", envKey: "WALLET_USDT_TRC20" },
  { id: "trx", label: "TRX", network: "TRON", symbol: "T", envKey: "WALLET_TRX" },
  { id: "ton", label: "TON", network: "TON Network", symbol: "◈", envKey: "WALLET_TON" },
  { id: "usdt_bep20", label: "USDT", network: "BEP20", symbol: "₮", envKey: "WALLET_USDT_BEP20" },
] as const;

export type PaymentMethodId = (typeof PAYMENT_METHODS)[number]["id"];

function paymentConfig() {
  return {
    baseUrl: process.env.CRYPTO_PAYMENT_API_BASE_URL?.replace(/\/$/, "") ?? "",
    createPath: process.env.CRYPTO_PAYMENT_CREATE_PATH ?? "/payments",
    apiKey: process.env.CRYPTO_PAYMENT_API_KEY ?? "",
  };
}

export function getPaymentMethod(id: PaymentMethodId) {
  return PAYMENT_METHODS.find((method) => method.id === id) ?? PAYMENT_METHODS[0];
}

export async function createPaymentInstruction(input: {
  orderId: string;
  amountUsd: number;
  paymentMethod: PaymentMethodId;
}) {
  const method = getPaymentMethod(input.paymentMethod);
  const savedSetting = await getPaymentSetting(input.paymentMethod);
  const walletAddress = savedSetting?.address ?? process.env[method.envKey] ?? "";
  const { baseUrl, createPath, apiKey } = paymentConfig();

  if (!baseUrl) {
    return {
      mode: "demo" as const,
      providerReference: null,
      address: walletAddress,
      method,
      note: walletAddress ? "عنوان دفع مُهيأ من الخادم" : "أضف عنوان المحفظة في إعدادات الخادم",
    };
  }

  const response = await fetch(`${baseUrl}${createPath}`, {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      ...(apiKey ? { authorization: `Bearer ${apiKey}` } : {}),
    },
    body: JSON.stringify({
      orderId: input.orderId,
      amount: input.amountUsd,
      currency: method.label,
      network: method.network,
    }),
  });
  const body = await response.text();
  if (!response.ok) {
    throw new Error(`Crypto payment provider rejected the request (${response.status})`);
  }
  const parsed = body ? (JSON.parse(body) as Record<string, unknown>) : {};
  return {
    mode: "external" as const,
    providerReference: typeof parsed.reference === "string" ? parsed.reference : null,
    address: typeof parsed.address === "string" ? parsed.address : walletAddress,
    method,
    note: "تم إنشاء طلب دفع لدى المزود",
  };
}

export function isCryptoProviderConfigured() {
  return Boolean(paymentConfig().baseUrl);
}
import { getPaymentSetting } from "./db";
