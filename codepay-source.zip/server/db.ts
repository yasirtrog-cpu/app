import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { codes, InsertCode, InsertOrder, orders, paymentSettings, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
type MemoryOrder = InsertOrder & { id: number; createdAt: Date; updatedAt: Date; status: NonNullable<InsertOrder["status"]> };
type MemoryCode = InsertCode & { id: number; createdAt: Date; updatedAt: Date; status: NonNullable<InsertCode["status"]> };
const memoryOrders: MemoryOrder[] = [];
const memoryCodes: MemoryCode[] = [];
let memoryOrderId = 1;
let memoryCodeId = 1;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch {
      console.warn("[Database] Failed to connect");
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      const value = user[field] ?? null;
      values[field] = value;
      updateSet[field] = value;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createOrder(input: Omit<InsertOrder, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) {
    const now = new Date();
    const order: MemoryOrder = { ...input, id: memoryOrderId++, status: input.status ?? "pending", createdAt: now, updatedAt: now };
    memoryOrders.push(order);
    return order;
  }
  const result = await db.insert(orders).values(input);
  const inserted = await getOrderByPublicId(input.publicId);
  return inserted ?? { ...input, id: Number(result[0].insertId), createdAt: new Date(), updatedAt: new Date(), status: input.status ?? "pending" };
}

export async function getOrderByPublicId(publicId: string) {
  const db = await getDb();
  if (!db) return memoryOrders.find((order) => order.publicId === publicId);
  const result = await db.select().from(orders).where(eq(orders.publicId, publicId)).limit(1);
  return result[0];
}

export async function updateOrder(publicId: string, patch: Partial<InsertOrder>) {
  const db = await getDb();
  if (!db) {
    const order = memoryOrders.find((item) => item.publicId === publicId);
    if (!order) return undefined;
    Object.assign(order, patch, { updatedAt: new Date() });
    return order;
  }
  await db.update(orders).set({ ...patch, updatedAt: new Date() }).where(eq(orders.publicId, publicId));
  return getOrderByPublicId(publicId);
}

export async function listOrders() {
  const db = await getDb();
  if (!db) return [...memoryOrders].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function listPaymentSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentSettings);
}

export async function upsertPaymentSetting(methodId: string, address: string, enabled: number) {
  const db = await getDb();
  if (!db) return { methodId, address, enabled };
  await db.insert(paymentSettings).values({ methodId, address: address || null, enabled }).onDuplicateKeyUpdate({
    set: { address: address || null, enabled, updatedAt: new Date() },
  });
  const result = await db.select().from(paymentSettings).where(eq(paymentSettings.methodId, methodId)).limit(1);
  return result[0];
}

export async function getPaymentSetting(methodId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(paymentSettings).where(eq(paymentSettings.methodId, methodId)).limit(1);
  return result[0];
}

export async function createCodes(items: InsertCode[]) {
  const db = await getDb();
  if (!db) {
    const now = new Date();
    const saved = items.map((item) => ({ ...item, id: memoryCodeId++, status: item.status ?? "active", createdAt: now, updatedAt: now })) as MemoryCode[];
    memoryCodes.push(...saved);
    return saved;
  }
  await db.insert(codes).values(items);
  const saved: typeof codes.$inferSelect[] = [];
  for (const item of items) {
    const found = await db.select().from(codes).where(eq(codes.code, item.code)).limit(1);
    if (found[0]) saved.push(found[0]);
  }
  return saved;
}

export async function getCodesForOrder(orderId: number) {
  const db = await getDb();
  if (!db) return memoryCodes.filter((code) => code.orderId === orderId);
  return db.select().from(codes).where(eq(codes.orderId, orderId));
}

export async function getCodeByValue(value: string) {
  const db = await getDb();
  if (!db) return memoryCodes.find((code) => code.code === value);
  const result = await db.select().from(codes).where(eq(codes.code, value)).limit(1);
  return result[0];
}

export async function markCodeExpired(id: number) {
  const db = await getDb();
  if (!db) {
    const code = memoryCodes.find((item) => item.id === id);
    if (code) Object.assign(code, { status: "expired", updatedAt: new Date() });
    return code;
  }
  await db.update(codes).set({ status: "expired", updatedAt: new Date() }).where(and(eq(codes.id, id), eq(codes.status, "active")));
  const result = await db.select().from(codes).where(eq(codes.id, id)).limit(1);
  return result[0];
}

import type { InsertUser } from "../drizzle/schema";
