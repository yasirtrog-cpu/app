import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter, handlePaymentWebhook } from "../routers";
import { verifyCode } from "../code-service";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";
import { ENV } from "./env";

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.get("/api/health", (_req, res) => res.json({ ok: true, timestamp: Date.now() }));

  app.get("/api/codes/verify", async (req, res) => {
    if (ENV.validationApiKey && req.header("x-api-key") !== ENV.validationApiKey) {
      res.status(401).json({ error: "Invalid API key" });
      return;
    }
    const code = typeof req.query.code === "string" ? req.query.code : "";
    if (!code) {
      res.status(400).json({ error: "code is required" });
      return;
    }
    try {
      res.json(await verifyCode(code));
    } catch {
      res.status(502).json({ error: "Code provider unavailable" });
    }
  });

  app.post("/api/payments/webhook", async (req, res) => {
    if (ENV.paymentWebhookSecret && req.header("x-webhook-secret") !== ENV.paymentWebhookSecret) {
      res.status(401).json({ error: "Invalid webhook secret" });
      return;
    }
    const { orderId, status, txid } = req.body ?? {};
    if (typeof orderId !== "string" || typeof status !== "string") {
      res.status(400).json({ error: "orderId and status are required" });
      return;
    }
    try {
      const result = await handlePaymentWebhook({ orderId, status, txid: typeof txid === "string" ? txid : null });
      res.json({ ok: true, ...result });
    } catch {
      res.status(500).json({ error: "Payment fulfillment failed" });
    }
  });

  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => console.log("[api] server listening"));
}
startServer().catch(() => console.error("[api] server failed to start"));
