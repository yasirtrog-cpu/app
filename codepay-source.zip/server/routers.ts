import crypto from "node:crypto";
import { z } from "zod";
import { getCodesForOrder, createOrder, getOrderByPublicId, updateOrder, listOrders, listPaymentSettings, upsertPaymentSetting } from "./db";
import { fulfillOrderByPublicId, verifyCode } from "./code-service";
import { PAYMENT_METHODS, createPaymentInstruction, isCryptoProviderConfigured, type PaymentMethodId } from "./payment-provider";
import { storagePut } from "./storage";
import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";

const durations = [
  { days: 1, label: "يوم واحد", pricePerCode: 1, hint: "تجربة سريعة" },
  { days: 2, label: "يومان", pricePerCode: 2, hint: "وصول لمدة 48 ساعة" },
  { days: 3, label: "3 أيام", pricePerCode: 3, hint: "للعمليات القصيرة" },
  { days: 7, label: "أسبوع", pricePerCode: 7, hint: "الأكثر مرونة" },
  { days: 30, label: "شهر", pricePerCode: 30, hint: "اشتراك كامل" },
] as const;
const paymentMethodSchema = z.enum(["usdt_trc20", "trx", "ton", "usdt_bep20"]);
const durationSchema = z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(7), z.literal(30)]);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(getSessionCookieName(ctx.req), { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  catalog: router({
    get: publicProcedure.query(() => ({
      codeLength: 7,
      priceUnit: "USD",
      pricingModel: "$1 لكل كود عن كل يوم",
      durations,
      paymentMethods: PAYMENT_METHODS.map(({ id, label, network, symbol }) => ({ id, label, network, symbol })),
      paymentProviderConfigured: isCryptoProviderConfigured(),
    })),
  }),
  orders: router({
    create: publicProcedure
      .input(z.object({ quantity: z.number().int().min(1).max(100), subscriptionDays: durationSchema, paymentMethod: paymentMethodSchema }))
      .mutation(async ({ input }) => {
        const duration = durations.find((item) => item.days === input.subscriptionDays)!;
        const totalCents = input.quantity * duration.pricePerCode * 100;
        const publicId = `CP-${crypto.randomBytes(5).toString("hex").toUpperCase()}`;
        const payment = await createPaymentInstruction({ orderId: publicId, amountUsd: totalCents / 100, paymentMethod: input.paymentMethod as PaymentMethodId });
        await createOrder({
          publicId,
          quantity: input.quantity,
          subscriptionDays: input.subscriptionDays,
          totalCents,
          paymentMethod: input.paymentMethod,
          paymentAddress: payment.address || null,
          paymentReference: payment.providerReference,
          status: "pending",
        });
        return {
          orderId: publicId,
          quantity: input.quantity,
          subscriptionDays: input.subscriptionDays,
          amountUsd: totalCents / 100,
          paymentMethod: payment.method,
          paymentAddress: payment.address || null,
          providerReference: payment.providerReference,
          mode: payment.mode,
          note: payment.note,
          status: "pending" as const,
        };
      }),
    confirmDemo: publicProcedure.input(z.object({ orderId: z.string().min(1) })).mutation(async ({ input }) => {
      if (isCryptoProviderConfigured()) throw new Error("هذا الطلب ينتظر تأكيد مزود الدفع عبر webhook وليس تأكيدًا يدويًا.");
      const order = await getOrderByPublicId(input.orderId);
      if (!order) throw new Error("الطلب غير موجود");
      if (order.status === "fulfilled") return { status: "fulfilled" as const, codes: await getCodesForOrder(order.id) };
      await updateOrder(input.orderId, { status: "paid", paidAt: new Date() });
      return { status: "paid" as const, codes: [] };
    }),
    get: publicProcedure.input(z.object({ orderId: z.string().min(1) })).query(async ({ input }) => {
      const order = await getOrderByPublicId(input.orderId);
      if (!order) return null;
      const savedCodes = order.status === "fulfilled" ? await getCodesForOrder(order.id) : [];
      return { ...order, totalUsd: order.totalCents / 100, codes: savedCodes };
    }),
    submitProof: publicProcedure.input(z.object({ orderId: z.string().min(1), fileName: z.string().max(120), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), base64: z.string().min(100).max(8_000_000) })).mutation(async ({ input }) => {
      const order = await getOrderByPublicId(input.orderId);
      if (!order) throw new Error("الطلب غير موجود");
      if (order.status !== "pending") throw new Error("لا يمكن رفع إثبات لهذا الطلب الآن");
      const raw = input.base64.replace(/^data:[^;]+;base64,/, "");
      const bytes = Buffer.from(raw, "base64");
      if (bytes.length > 5 * 1024 * 1024) throw new Error("حجم الصورة يتجاوز 5MB");
      const stored = await storagePut(`payment-proofs/${input.orderId}-${input.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`, bytes, input.mimeType);
      const updated = await updateOrder(input.orderId, { proofUrl: stored.url });
      return { orderId: input.orderId, proofUrl: updated?.proofUrl ?? stored.url, status: updated?.status ?? "pending" };
    }),
  }),
  codes: router({
    verify: publicProcedure.input(z.object({ code: z.string().min(5).max(32) })).mutation(async ({ input }) => verifyCode(input.code)),
  }),
  admin: router({
    overview: adminProcedure.query(async ({ ctx }) => ({ user: ctx.user, orders: await listOrders(), settings: await listPaymentSettings() })),
    reviewOrder: adminProcedure.input(z.object({ orderId: z.string().min(1), decision: z.enum(["approve", "reject"]), rejectReason: z.string().max(500).optional() })).mutation(async ({ input }) => {
      const order = await getOrderByPublicId(input.orderId);
      if (!order) throw new Error("الطلب غير موجود");
      if (input.decision === "reject") {
        const updated = await updateOrder(input.orderId, { status: "failed", rejectReason: input.rejectReason?.trim() || "لم يثبت وصول الدفع أو كانت الصورة غير واضحة.", reviewedAt: new Date() });
        return { status: updated?.status ?? "failed", codes: [] };
      }
      await updateOrder(input.orderId, { status: "paid", paidAt: new Date(), reviewedAt: new Date(), rejectReason: null });
      return { status: "paid" as const, codes: [] };
    }),
    saveWallet: adminProcedure.input(z.object({ methodId: paymentMethodSchema, address: z.string().max(255), enabled: z.boolean() })).mutation(async ({ input }) => {
      return upsertPaymentSetting(input.methodId, input.address.trim(), input.enabled ? 1 : 0);
    }),
  }),
});

export async function handlePaymentWebhook(input: { orderId: string; status: string; txid?: string | null }) {
  const order = await getOrderByPublicId(input.orderId);
  if (!order) throw new Error("Order not found");
  if (input.status === "failed") {
    await updateOrder(input.orderId, { status: "failed", paymentReference: input.txid ?? order.paymentReference });
    return { status: "failed" as const, codes: [] };
  }
  if (input.status !== "paid" && input.status !== "confirmed") return { status: order.status, codes: [] };
  await updateOrder(input.orderId, { status: "paid", paidAt: new Date(), paymentReference: input.txid ?? order.paymentReference });
  const codes = await fulfillOrderByPublicId(input.orderId);
  return { status: "fulfilled" as const, codes };
}

export type AppRouter = typeof appRouter;
