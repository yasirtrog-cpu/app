import { createCodes, getCodeByValue, getCodesForOrder, getOrderByPublicId, markCodeExpired, updateOrder } from "./db";
import { generateCode, isExternalCodeApiConfigured, pushCodesToExternalApi, verifyCodeWithExternalApi } from "./code-provider";

export async function fulfillOrderByPublicId(publicId: string) {
  const order = await getOrderByPublicId(publicId);
  if (!order) throw new Error("Order not found");
  const existing = await getCodesForOrder(order.id);
  if (existing.length >= order.quantity) {
    await updateOrder(publicId, { status: "fulfilled" });
    return existing;
  }
  const codes = Array.from({ length: order.quantity }, generateCode);
  const expiresAt = new Date(Date.now() + order.subscriptionDays * 24 * 60 * 60 * 1000);
  await pushCodesToExternalApi({ codes, subscriptionDays: order.subscriptionDays, expiresAt });
  const saved = await createCodes(
    codes.map((code) => ({
      code,
      orderId: order.id,
      subscriptionDays: order.subscriptionDays,
      expiresAt,
      status: "active" as const,
    })),
  );
  await updateOrder(publicId, { status: "fulfilled", paidAt: order.paidAt ?? new Date() });
  return saved;
}

export async function verifyCode(value: string) {
  const normalized = value.trim().toUpperCase();
  if (isExternalCodeApiConfigured()) {
    return verifyCodeWithExternalApi(normalized);
  }
  const record = await getCodeByValue(normalized);
  if (!record) {
    return { exists: false, valid: false, status: "not_found", expiresAt: null, subscriptionDays: null, source: "local" as const };
  }
  if (record.status === "active" && record.expiresAt.getTime() <= Date.now()) {
    const expired = await markCodeExpired(record.id);
    return { exists: true, valid: false, status: expired?.status ?? "expired", expiresAt: record.expiresAt.toISOString(), subscriptionDays: record.subscriptionDays, source: "local" as const };
  }
  return {
    exists: true,
    valid: record.status === "active",
    status: record.status,
    expiresAt: record.expiresAt.toISOString(),
    subscriptionDays: record.subscriptionDays,
    source: "local" as const,
  };
}
