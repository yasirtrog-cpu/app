/** @type {const} */
const themeColors = {
  primary: { light: '#168B74', dark: '#45E0B3' },
  background: { light: '#F4F7F2', dark: '#081A2B' },
  surface: { light: '#FFFFFF', dark: '#102B40' },
  foreground: { light: '#081A2B', dark: '#F4F7F2' },
  muted: { light: '#56707B', dark: '#9EB5C3' },
  border: { light: '#D3E3DE', dark: '#285067' },
  success: { light: '#168B74', dark: '#45E0B3' },
  warning: { light: '#B87900', dark: '#FFC857' },
  error: { light: '#C54255', dark: '#FF7D8A' },
};

module.exports = { themeColors };
