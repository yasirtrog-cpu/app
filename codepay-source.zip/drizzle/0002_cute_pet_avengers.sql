CREATE TABLE `paymentSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`methodId` varchar(32) NOT NULL,
	`address` varchar(255),
	`enabled` int NOT NULL DEFAULT 1,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `paymentSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `paymentSettings_methodId_unique` UNIQUE(`methodId`)
);
--> statement-breakpoint
ALTER TABLE `orders` ADD `proofUrl` varchar(500);--> statement-breakpoint
ALTER TABLE `orders` ADD `rejectReason` text;--> statement-breakpoint
ALTER TABLE `orders` ADD `reviewedAt` timestamp;