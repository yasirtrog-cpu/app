CREATE TABLE `codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`orderId` int NOT NULL,
	`subscriptionDays` int NOT NULL,
	`status` enum('active','expired','revoked') NOT NULL DEFAULT 'active',
	`expiresAt` timestamp NOT NULL,
	`externalId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `codes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publicId` varchar(64) NOT NULL,
	`quantity` int NOT NULL,
	`subscriptionDays` int NOT NULL,
	`totalCents` int NOT NULL,
	`paymentMethod` enum('usdt_trc20','trx','ton','usdt_bep20') NOT NULL,
	`paymentAddress` varchar(255),
	`paymentReference` varchar(255),
	`status` enum('pending','paid','fulfilled','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`paidAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_publicId_unique` UNIQUE(`publicId`)
);
